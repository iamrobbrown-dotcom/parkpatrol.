# ParkPatrol — iPhone car park management

Free, local-first parking patrol progressive web app. No login, subscriptions, or hard-coded limit on cars, visits or sightings. Source is included and editable.

## What it does

- Take a photo with your iPhone's rear camera, or choose a picture from Photos.
- Browser OCR suggests a number plate (requires review; it is not infallible). Drag a rectangle over the plate to improve reading.
- Correct or enter registration numbers manually.
- Log registration, exact observation timestamp, zone, parking time limit, notes, and compressed photo evidence.
- Automatically group repeat sightings into a visit until the configurable gap has passed; close a visit manually where appropriate.
- Flag possible overstays only if at least two sightings span the zone's parking time limit. Flag single sightings as due for recheck after the limit has passed.
- Search vehicles and history, CSV export and JSON backup including photos; restore/merge backups.
- Add zones for visitor bays, loading docks etc., each with its own time limit.
- All data is in the browser's IndexedDB on that iPhone. No plate/photo uploads, no backend.

## Use it on an iPhone (recommended)

This is a **web app / PWA**, not an App Store installation. To get a permanent iPhone home-screen icon, host these files on a site using **HTTPS** (GitHub Pages is free):

1. Create a GitHub repository, for example `parkpatrol`.
2. Upload all the contents of this folder to the repository root (keep `assets` as a folder). Choose **Commit changes**.
3. Go to **Settings → Pages** and choose **Deploy from a branch → main / (root)**, then **Save**.
4. After Pages deploys, open the provided `https://…github.io/parkpatrol/` site on the **iPhone in Safari**.
5. Tap Safari's **Share** button → **Add to Home Screen** → **Add**.
6. Use the home-screen app, not Private Browsing, for persistent local records.

To run locally on a computer, from inside the folder: `python3 -m http.server 8000`, then open http://localhost:8000 in a browser.

**Opening index.html from Files may fail to save observations** because iOS local-file previews are not a reliable origin for IndexedDB. HTTPS hosting is recommended for real use.

## OCR behaviour

The app uses the open-source Tesseract.js OCR library (`https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/tesseract.min.js`), which loads on the first photo scan and may fetch a language pack and WebAssembly code. After loading, recognition runs **on the device**. It does not upload your photo to an OCR API. Internet access is needed to load any uncached OCR resources; manual logging remains available without it. Recognition is OCR of image text, **not** a purpose-built Australian number-plate recognition model. Check the suggested registration carefully. The interface, saving workflow, visit alerts and photo-review flow were exercised in desktop Chromium using a simulated database and OCR response. Actual persistent storage, the camera and OCR accuracy have not yet been tested on a physical iPhone.

## Evidence caveats

- “Possible overstay” means the first and last observed timestamps span the parking limit. Repeated observations do **not** demonstrate that the vehicle stayed continuously in the same bay.
- An observation marked “Recheck due” is **not** a confirmed overstay; the vehicle might have departed since its last sighting.
- The app does not issue infringement notices or identify registered vehicle owners.
- The timestamp is when you log the observation (editable before saving). For existing imported photos, check and set the original time manually: file timestamps might not reflect original capture time.

## Privacy, safety and durability

- Store only vehicle observations you are authorised to record. Comply with applicable NSW strata/by-law, surveillance, notice, and privacy obligations.
- Local phone storage has capacity limits and can be cleared/evicted by iOS or Safari. **Export backups regularly** and save them somewhere safe. Backups include identifiable number plates and photos; treat them as sensitive.
- Screen lock and encrypted device backup are recommended. The data is not encrypted separately by the app.
- The app has no subscriptions, licensing fees or vehicle-count cap, but does not promise literally infinite storage; capacity is controlled by the browser/device.
- For shared multi-guard access, reliable court-grade tamper-evident evidence, or central synchronisation, a hosted backend and stronger audit trail would be required.

## Technical details

Plain HTML/CSS/JavaScript. No build process or backend required. Uses IndexedDB for persistence, Tesseract.js for local OCR and a cache-first Service Worker for the app shell. Files can be modified and redeployed. Licensed for the recipient to modify and use.
