# ParkPatrol: get it onto your iPhone

ParkPatrol is an installable web app (PWA), not an App Store app. It runs in Safari and, once added to the Home Screen, opens full-screen like an app. Your observations and photos are stored locally on that iPhone.

## Publish with GitHub Pages — no paid hosting required

1. Sign in to GitHub at https://github.com and create a **new public repository** named `parkpatrol`. You can name it something else if you like. (A public GitHub Pages site shows the *app code*, not the parking observations on your phone.)
2. Download **ParkPatrol-iPhone-Ready.zip** and unzip/extract it.
3. On your new repository's **Code** tab, select **Add file → Upload files**. Upload the *contents of the unzipped folder*, keeping `index.html`, `app.js`, `app.css`, `manifest.webmanifest`, `sw.js`, `.nojekyll` and the `assets` folder in their original paths. Uploading the ZIP itself does not publish the app; GitHub Pages needs the extracted files. Commit the upload to `main`.
4. Open **Settings → Pages**. For **Build and deployment**, choose **Deploy from a branch**, set `main` and `/(root)`, and select **Save**.
5. Under **Settings → Pages**, select **Visit site** when GitHub shows the published URL. The address normally follows `https://YOURUSERNAME.github.io/parkpatrol/`. Do not assume the site is live until GitHub shows it.
6. On your iPhone, open that **HTTPS** address in **Safari** (not Private Browsing). Tap Safari's **Share** control → **Add to Home Screen**. Leave **Open as Web App** on if shown, and tap **Add**.
7. Open **ParkPatrol** using the new Home Screen icon. Add a manual test registration, close/reopen the app and verify it is still there, then test camera and recognition.

If you use GitHub only from your phone, you can unzip the ZIP in iOS **Files** by tapping it, then use Safari on GitHub to upload the extracted files. It's often easier to perform the upload step from a computer because the site needs multiple files and an `assets` subfolder.

## Important

- Camera/photo OCR is an **assisted suggestion**; always visually confirm the registration before saving. OCR initially downloads an engine from a public CDN, so internet is required for the first scan or whenever OCR resources are not cached. Manual entries do not require OCR.
- ParkPatrol's core screens are cached for offline use after a successful online visit. Make sure the app is opened online after installation before relying on offline operation.
- App records are **not on GitHub**. They are stored in the iPhone's browser storage (IndexedDB). Each device has its own independent records; uninstalling, deleting site data or iOS storage cleanup can remove records. Back up often via **Settings → Download backup**, which includes photos; also use CSV export if needed. Store backups somewhere secure.
- The same parking space must be observed more than once before the app can flag a *possible* overstay. A flag is not proof of continuous occupancy.
- GitHub Pages publishes a public website; never upload a backup JSON, photos of vehicles, or registration records to the repository.

## Troubleshooting

**It won't save:** confirm the URL starts with `https://`, you're not previewing `index.html` in Files, and you're not in Private Browsing.

**Camera doesn't open:** use Safari on iPhone; check that the website can access Photos/camera, and retry using **Choose existing photo**.

**No plate recognised:** connect to internet, wait for the OCR engine to load, draw a box around just the plate, and choose **Read number plate from photo** again. You can always type the plate manually.

**Old design after an update:** reopen the site online in Safari, reload it, then reopen the Home Screen app.

**No GitHub repo connected to ChatGPT:** create the repository on GitHub and enable/authorise it for the GitHub connection before asking ChatGPT to publish or amend files there.
